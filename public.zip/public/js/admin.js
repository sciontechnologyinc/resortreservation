$(document).ready(function() {

    $("#signout-btn").click(function() {
        alert("Successfully Sign out!");
    });

});